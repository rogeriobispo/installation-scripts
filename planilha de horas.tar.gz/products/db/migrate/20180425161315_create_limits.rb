class CreateLimits < ActiveRecord::Migration[5.2]
  def change
    create_table :limits do |t|
      t.timestamps
      t.timestamp :deleted_at
      t.integer :status
      t.references :product, foreign_key: true
      t.references :service, foreign_key: true
      t.timestamp :validity_start
      t.integer :period
      t.integer :limit
    end
  end
end
