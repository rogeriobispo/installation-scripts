class CreateProducts < ActiveRecord::Migration[5.2]
  def change
    create_table :products do |t|
      t.timestamps
      t.timestamp :deleted_at
      t.integer :status
      t.string :name
    end
  end
end
