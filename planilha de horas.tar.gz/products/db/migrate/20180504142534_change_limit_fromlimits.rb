class ChangeLimitFromlimits < ActiveRecord::Migration[5.2]
  def change
     rename_column :limits, :limit, :amount
  end
end
