class CreateProductMappings < ActiveRecord::Migration[5.2]
  def change
    create_table :product_mappings do |t|
      t.timestamps
      t.references :product, foreign_key: true
      t.references :pack, foreign_key: true
      t.integer :product_legacy_id
    end
  end
end
