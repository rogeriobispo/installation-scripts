class CreatePacks < ActiveRecord::Migration[5.2]
  def change
    create_table :packs do |t|
      t.timestamps
      t.timestamp :deleted_at
      t.integer :status
      t.string :name
      t.references :product, foreign_key: true
      t.boolean :default
      t.timestamp :validity_start
      t.timestamp :validity_end
      t.integer :type
    end
  end
end
