class CreatePackServices < ActiveRecord::Migration[5.2]
  def change
    create_table :pack_services do |t|
      t.timestamps
      t.timestamp :deleted_at
      t.timestamp :validity_start
      t.references :pack, foreign_key: true
      t.references :service, foreign_key: true
      t.references :limit, foreign_key: true
    end
  end
end
