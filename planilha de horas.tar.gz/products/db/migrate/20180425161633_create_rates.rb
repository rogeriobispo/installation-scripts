class CreateRates < ActiveRecord::Migration[5.2]
  def change
    create_table :rates do |t|
      t.timestamps
      t.timestamp :deleted_at
      t.references :pack, foreign_key: true
      t.references :service, foreign_key: true
      t.timestamp :validity_start
      t.integer :composition
      t.integer :type
      t.float :rate
    end
  end
end
