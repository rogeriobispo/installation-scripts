# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 2018_05_04_142534) do

  create_table "limits", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.timestamp "deleted_at"
    t.integer "status"
    t.bigint "product_id"
    t.bigint "service_id"
    t.timestamp "validity_start"
    t.integer "period"
    t.integer "amount"
    t.index ["product_id"], name: "index_limits_on_product_id"
    t.index ["service_id"], name: "index_limits_on_service_id"
  end

  create_table "pack_services", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.timestamp "deleted_at"
    t.timestamp "validity_start"
    t.bigint "pack_id"
    t.bigint "service_id"
    t.bigint "limit_id"
    t.index ["limit_id"], name: "index_pack_services_on_limit_id"
    t.index ["pack_id"], name: "index_pack_services_on_pack_id"
    t.index ["service_id"], name: "index_pack_services_on_service_id"
  end

  create_table "packs", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.timestamp "deleted_at"
    t.integer "status"
    t.string "name"
    t.bigint "product_id"
    t.boolean "default"
    t.timestamp "validity_start"
    t.timestamp "validity_end"
    t.integer "type"
    t.index ["product_id"], name: "index_packs_on_product_id"
  end

  create_table "product_mappings", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "product_id"
    t.bigint "pack_id"
    t.integer "product_legacy_id"
    t.index ["pack_id"], name: "index_product_mappings_on_pack_id"
    t.index ["product_id"], name: "index_product_mappings_on_product_id"
  end

  create_table "product_services", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "product_id"
    t.bigint "service_id"
    t.index ["product_id"], name: "index_product_services_on_product_id"
    t.index ["service_id"], name: "index_product_services_on_service_id"
  end

  create_table "products", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.timestamp "deleted_at"
    t.integer "status"
    t.string "name"
  end

  create_table "rates", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.timestamp "deleted_at"
    t.bigint "pack_id"
    t.bigint "service_id"
    t.timestamp "validity_start"
    t.integer "composition"
    t.integer "type"
    t.float "rate"
    t.index ["pack_id"], name: "index_rates_on_pack_id"
    t.index ["service_id"], name: "index_rates_on_service_id"
  end

  create_table "services", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.timestamp "deleted_at"
    t.integer "status"
    t.string "name"
  end

  add_foreign_key "limits", "products"
  add_foreign_key "limits", "services"
  add_foreign_key "pack_services", "limits"
  add_foreign_key "pack_services", "packs"
  add_foreign_key "pack_services", "services"
  add_foreign_key "packs", "products"
  add_foreign_key "product_mappings", "packs"
  add_foreign_key "product_mappings", "products"
  add_foreign_key "product_services", "products"
  add_foreign_key "product_services", "services"
  add_foreign_key "rates", "packs"
  add_foreign_key "rates", "services"
end
