require 'rails_helper'

RSpec.describe CreateProductService, type: :service do
  before do
    @product = create(:product)
    @service = create(:service)

    @prod_serv_param = { product_id: @product.id, service_id: @service.id }
  end

  describe 'cria um product_service' do
    context 'sucesso' do
      it 'objeto criado' do
        product_service = CreateProductService.new(@prod_serv_param)
        expect(product_service).to broadcast(:successfully)
      end
    end

    context 'falha' do
      it 'se ja existir relacionamento' do
        product_service = CreateProductService.new(@prod_serv_param)
        product_service.call
        expect(product_service).to broadcast(:failed)
      end

      it 'se produto nao existir' do
        missing_param = { service_id: @service.id }
        product_service = CreateProductService.new(missing_param)
        expect(product_service).to broadcast(:failed)
      end

      it 'se servico não existir' do
        missing_param = { product_id: @product.id }
        product_service = CreateProductService.new(missing_param)
        expect(product_service).to broadcast(:failed)
      end
    end
  end
end
