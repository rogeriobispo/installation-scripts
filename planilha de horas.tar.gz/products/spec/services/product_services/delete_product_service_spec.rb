require 'rails_helper'


RSpec.describe CreateProductService, type: :service do


  describe 'deleta um product_service' do
    context 'quando product_service existe' do
      it 'deletado' do
        @product_service = create(:product_service)
        param = { id: @product_service.id }
        product_service = DeleteProductService.new(param)
        expect(product_service).to broadcast(:destroyed)
      end

    end

    context 'quando product_service não existe' do
      it 'returna not_found' do
        param = { id: 100000 }
        product_service = DeleteProductService.new(param)
        expect(product_service).to broadcast(:not_found)
      end
    end
  end
end
