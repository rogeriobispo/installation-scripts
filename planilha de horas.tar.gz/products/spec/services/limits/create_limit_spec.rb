require 'rails_helper'

RSpec.describe CreateLimit, type: :service do
  before do
    @product = create(:product)
    @service = create(:service)
    limit_params = {
       product_id: @product.id,
       service_id: @service.id,
       validity_start: (Date.today + 10.days).to_s,
       status: 'enabled',
       period: 'monthly',
       amount: 5
      }
    @limit_params = ActionController::Parameters.new(limit_params)
  end

  describe 'factory limit' do
    context 'successfull' do
      it 'create new object' do
        limit = CreateLimit.new(@limit_params)
        expect(limit).to broadcast(:successfull)
      end

      it 'only broadcast successfull' do
        limit = CreateLimit.new(@limit_params)
        expect(limit).not_to broadcast(:failed)
        limit.call
      end
    end

    context 'failure' do

      it 'an exception is thrown' do
        @limit_params[:product_id]= 'A'
        limit = CreateLimit.new(@limit_params)
        limit.on(:failed) do |message|
          expect(message[:product_id]).to include('must be an integer')
        end
        limit.call
        expect(limit).to broadcast(:failed)
      end

      it 'duplicated limit not permited' do
        limit = CreateLimit.new(@limit_params)
        limit.call
        limit.on(:failed) do |message|
          expect(message[:product_id]).to include('product x service must be unique')
          end

        expect(limit).to broadcast(:failed)
      end

      it 'product_id param missing' do
        @limit_params[:product_id]= nil
        limit = CreateLimit.new(@limit_params)
        limit.on(:failed) do |message|
          expect(message[:product_id]).to include('must be filled')
        end
        expect(limit).to broadcast(:failed)
      end

      it 'service_id param missing' do
        @limit_params[:service_id]= nil
        limit = CreateLimit.new(@limit_params)
        limit.on(:failed) do |message|
          expect(message[:service_id]).to include('must be filled')
        end
        expect(limit).to broadcast(:failed)
      end

      it 'validity_start param missing' do
        @limit_params[:validity_start]= nil
        limit = CreateLimit.new(@limit_params)
        limit.on(:failed) do |message|
          expect(message[:validity_start]).to include('must be filled')
        end
        expect(limit).to broadcast(:failed)
      end


      it 'validat_start date less than today' do
        @limit_params[:validity_start]=  Date.today - 1.day
         expected = "must be greater than or equal to #{Date.today.strftime("%Y-%m-%d")}"
        limit = CreateLimit.new(@limit_params)
        limit.on(:failed) do |message|
          expect(message[:validity_start]).to include(expected)
        end
        expect(limit).to broadcast(:failed)
      end

      it 'limit param missing' do
        @limit_params[:amount]= nil
        limit = CreateLimit.new(@limit_params)
        limit.on(:failed) do |message|
          expect(message[:amount]).to include('must be filled')
        end
        expect(limit).to broadcast(:failed)
      end
    end
  end
end
