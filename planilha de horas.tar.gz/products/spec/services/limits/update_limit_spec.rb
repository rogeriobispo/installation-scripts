require 'rails_helper'

RSpec.describe UpdateLimit, type: :service do
  before do
    product = create(:product)
    service = create(:service)
    limit = Limit.create(product: product, service: service)
    @limit_params = {
      id: limit.id,
       status: 'enabled',
       period: 'weekly',
       amount: 5
      }
  end

  describe 'factory limit' do
    context 'successfull' do
      it 'update limit' do
        limit = UpdateLimit.new(@limit_params)
        expect(limit).to broadcast(:successfull)
        limit.call
      end
    end

    context 'failure' do

      it 'an exception is thrown' do
        @limit_params[:product_id]= 'A'
        limit = UpdateLimit.new(@limit_params)
        limit.on(:failed) do |message|
          expect(message[:product_id]).to include('must be an integer')
        end
        limit.call
        expect(limit).to broadcast(:failed)
      end

      it 'duplicated limit not permited' do
        limit = UpdateLimit.new(@limit_params)
        limit.call
        limit.on(:failed) do |message|
          expect(message[:product_id]).to include('product x service must be unique')
          end

        expect(limit).to broadcast(:failed)
      end

      it 'product_id param missing' do
        @limit_params[:product_id]= nil
        limit = UpdateLimit.new(@limit_params)
        limit.on(:failed) do |message|
          expect(message[:product_id]).to include('must be filled')
        end
        expect(limit).to broadcast(:failed)
      end

      it 'service_id param missing' do
        @limit_params[:service_id]= nil
        limit = UpdateLimit.new(@limit_params)
        limit.on(:failed) do |message|
          expect(message[:service_id]).to include('must be filled')
        end
        expect(limit).to broadcast(:failed)
      end

      it 'validity_start param missing' do
        @limit_params[:validity_start]= nil
        limit = UpdateLimit.new(@limit_params)
        limit.on(:failed) do |message|
          expect(message[:validity_start]).to include('must be filled')
        end
        expect(limit).to broadcast(:failed)
      end

      it 'limit param missing' do
        @limit_params[:amount]= nil
        limit = UpdateLimit.new(@limit_params)
        limit.on(:failed) do |message|
          expect(message[:amount]).to include('must be filled')
        end
        expect(limit).to broadcast(:failed)
      end
    end
  end
end
