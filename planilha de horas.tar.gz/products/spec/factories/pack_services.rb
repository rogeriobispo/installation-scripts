FactoryBot.define do
  factory :pack_service do
    deleted_at "2018-04-25 13:33:02"
    validity_start "2018-04-25 13:33:02"
    pack nil
    service nil
    limit nil
  end
end
