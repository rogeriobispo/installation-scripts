FactoryBot.define do
  factory :product_mapping do
    product nil
    pack nil
    product_legacy_id 1
  end
end
