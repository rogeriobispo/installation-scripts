FactoryBot.define do
  factory :pack do
    name "MyString"
    status ""
    deleted_at "2018-04-25 11:11:52"
    product nil
    default false
    validity_start "2018-04-25 11:11:52"
    validity_end "2018-04-25 11:11:52"
    type ""
  end
end
