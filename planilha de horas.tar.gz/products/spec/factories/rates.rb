FactoryBot.define do
  factory :rate do
    deleted_at "2018-04-25 13:16:33"
    validity_start "2018-04-25 13:16:33"
    pack nil
    service nil
    type 1
    rate 1.5
    composition 1
  end
end
