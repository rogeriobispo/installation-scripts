FactoryBot.define do
  factory :parameter do
    deleted_at "2018-04-25 13:20:07"
    status 1
    name "MyString"
    data_type 1
    default_value "MyString"
    readonly false
  end
end
