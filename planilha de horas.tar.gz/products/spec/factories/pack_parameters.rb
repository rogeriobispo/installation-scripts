FactoryBot.define do
  factory :pack_parameter do
    deleted_at "2018-04-25 13:25:10"
    pack nil
    parameter nil
    validity_start "2018-04-25 13:25:10"
    value "MyString"
  end
end
