FactoryBot.define do
  factory :product do
    name "MyString"
    status ""
    deleted_at "2018-04-25 11:06:23"
  end
end
