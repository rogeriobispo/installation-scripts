FactoryBot.define do
  factory :product_service do
    product
    service
  end
end
