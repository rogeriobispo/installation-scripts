FactoryBot.define do
  factory :service do
    name "MyString"
    status ""
    deleted_at "2018-04-25 11:08:22"
  end
end
