FactoryBot.define do
  factory :limit do
    deleted_at "2018-04-25 13:13:15"
    status 1
    :product
    :service
    validity_start "2018-04-25 13:13:15"
    period 1
    limit 1
  end
end
