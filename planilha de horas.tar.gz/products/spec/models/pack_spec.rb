require 'rails_helper'

RSpec.describe Pack, type: :model do
end
