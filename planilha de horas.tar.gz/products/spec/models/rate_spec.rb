require 'rails_helper'

RSpec.describe Rate, type: :model do
end
