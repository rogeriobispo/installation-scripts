require 'rails_helper'

RSpec.describe ProductMapping, type: :model do
end
