require 'rails_helper'

RSpec.describe Limit, type: :model do
end
