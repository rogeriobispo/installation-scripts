require 'rails_helper'

RSpec.describe ProductService, type: :model do
end
