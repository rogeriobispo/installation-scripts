require 'rails_helper'

RSpec.describe PackService, type: :model do
end
