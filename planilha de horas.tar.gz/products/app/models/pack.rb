class Pack < ApplicationRecord
  belongs_to :product
  has_many :pack_services
  has_many :services, through: :pack_services
  has_many :limits, through: :pack_services
end
