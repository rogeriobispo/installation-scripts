class Limit < ApplicationRecord
  belongs_to :product
  belongs_to :service
  enum status: [ :acive, :inactive ]
  enum  period: [ :weekly ]
end
