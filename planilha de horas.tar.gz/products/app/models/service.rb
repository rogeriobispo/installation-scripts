class Service < ApplicationRecord
  has_many :product_services
  has_many :products, through: :product_services
  has_many :pack_services
  has_many :packs, through: :pack_services
  has_many :limits
end
