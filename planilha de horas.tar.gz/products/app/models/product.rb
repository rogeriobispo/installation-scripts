class Product < ApplicationRecord
  has_many :product_services
  has_many :services, through: :product_services
end
