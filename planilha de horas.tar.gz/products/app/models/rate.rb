class Rate < ApplicationRecord
  belongs_to :pack
  belongs_to :service
end
