class ProductService < ApplicationRecord
  belongs_to :product
  belongs_to :service
  validates_with ProductServiceExistValidator
end
