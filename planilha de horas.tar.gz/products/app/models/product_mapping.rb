class ProductMapping < ApplicationRecord
  belongs_to :product
  belongs_to :pack
end
