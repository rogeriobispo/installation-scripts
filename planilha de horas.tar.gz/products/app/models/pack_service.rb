class PackService < ApplicationRecord
  belongs_to :pack
  belongs_to :service
  belongs_to :limit
end
