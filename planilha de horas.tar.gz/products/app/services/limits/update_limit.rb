class UpdateLimit
  include Wisper::Publisher

  def initialize(params)
    @params = params
  end

  def call
    begin
      if validate?
        binding.pry
        limit = Limit.find(@params[:id])
        limit.update_attributes!(@params)
        broadcast(:successfull, limit)
      end
    rescue => ex
        broadcast(:failed, ex)
    end
  end

  private

  def validate?
    schema = Dry::Validation.JSON do
    configure do
        def duplicate?(product_id, service_id)
          true unless Limit.where(product_id: product_id, service_id: service_id).exists?
        end

        def self.messages
           super.merge(en: { errors: { duplicate?: 'product x service must be unique' } })
        end
      end

      required(:product_id).filled(:int?)
      required(:service_id).filled(:int?)
      required(:validity_start, :Date).filled(:date_time?, gteq?: Date.today)
      required(:status).filled(:str?)
      required(:period).filled(:str?)
      required(:amount).filled(:int?)
      validate(duplicate?: [:service_id, :product_id ]) do |service_id, product_id|
        duplicate?(service_id, product_id)
      end
    end

    validator = schema.call(@params)

    if validator.failure?
      broadcast(:failed, validator.messages)
      false
    else
      true
    end
  end
end
