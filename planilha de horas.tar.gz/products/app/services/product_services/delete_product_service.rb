class DeleteProductService
  include Wisper::Publisher

  def initialize(params)
    @product_service_id = params[:id]
  end

  def call
    product_service = ProductService.where(id: @product_service_id)
    if product_service.exists?
      product_service.first.destroy
      broadcast(:destroyed)
    else
      broadcast(:not_found)
    end
  end
end
