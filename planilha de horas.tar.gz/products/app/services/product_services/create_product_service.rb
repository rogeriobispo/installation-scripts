class CreateProductService
  include Wisper::Publisher

  def initialize(params)
    @product_id = params[:product_id]
    @service_id = params[:service_id]
  end

  def call
    product_service = ProductService.new(product_id: @product_id, service_id: @service_id)
    if product_service.save
      broadcast(:successfully, product_service)
    else
      broadcast(:failed, product_service)
    end
  end
end
