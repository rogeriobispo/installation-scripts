module V1
  class ProductServicesController < ApplicationController
    def create
      product_service = CreateProductService.new(product_service_params)

<<<<<<< Updated upstream
      product_service.on(:successfully) do |product_service|
        render json: product_service, status: :ok
      end

      product_service.on(:failed) do |product_service|
        render json: product_service.errors, status: :unprocessable_entity
=======
      product_service.on(:successfully) do |relation|
        render json: relation, status: :ok
      end

      product_service.on(:failed) do |relation|
        render json: relation.errors, status: :unprocessable_entity
>>>>>>> Stashed changes
      end

      product_service.call
    end

    def destroy
      product_service = DeleteProductService.new(params)

<<<<<<< Updated upstream
      product_service.on(:destroyed) do |product_service|
        render json: { status: 'deleted' }, status: :ok
      end

      product_service.on(:not_found) do |product_service|
=======
      product_service.on(:destroyed) do
        render json: { status: 'deleted' }, status: :ok
      end

      product_service.on(:not_found) do
>>>>>>> Stashed changes
        render json: { status: 'not_found'  }, status: :not_found
      end

      product_service.call
    end

    private

    def product_service_params
      params.permit(:service_id, :product_id)
    end
  end
end
