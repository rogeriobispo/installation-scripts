module V1
  class LimitsController < ApplicationController
    def create
      limit = CreateLimit.new(create_params)
      limit.on(:successfull) do |limit|
        render json: limit, status: :ok
      end

      limit.on(:failed) do |messages|
        render json: messages, status: :unprocessable_entity
      end
      limit.call
    end

    private

    def create_params
     params.permit(:product_id,
                                   :service_id,
                                   :validity_start,
                                   :status,
                                   :period,
                                   :amount)
    end
  end
end
