class ProductServiceExistValidator < ActiveModel::Validator
  def validate(transaction)
    msg = 'Relation product X service alread exists'
    transaction.errors.add(:product_service_exists, msg) if relation_exists?(transaction)
  end

  private

  def relation_exists?(transaction)
    ProductService.where(product_id: transaction.product_id, service_id: transaction.service_id).exists?
  end
end
